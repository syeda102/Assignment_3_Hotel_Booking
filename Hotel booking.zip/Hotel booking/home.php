<?php

include 'config.php';
session_start();

// page redirect
$usermail="";
$usermail=$_SESSION['usermail'];
if($usermail == true){

}else{
  header("location: index.php");
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/home.css">
    <title>Hotel LuxeStay</title>
    <!-- boot -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- fontowesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <!-- sweet alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="./admin/css/roombook.css">
    <style>
      #guestdetailpanel{
        display: none;
      }
      #guestdetailpanel .middle{
        height: 450px;
      }
    </style>
</head>

<body>
  <nav>
    <div class="logo">
      <img class="luxestaylogo" src="./new_images/logo2.png" alt="logo">
    </div>
    <ul>
      <li><a href="#firstsection">Home</a></li>
      <li><a href="#secondsection">Rooms</a></li>
      <li><a href="#thirdsection">Facilites</a></li>
      <li><a href="#contactus">contact us</a></li>
      <a href="./logout.php"><button class="btn btn-danger">Logout</button></a>
    </ul>
  </nav>

  <section id="firstsection" class="carousel slide carousel_section" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img class="carousel-image" src="./new_images/hotel1.jpg">
        </div>
        <div class="carousel-item">
            <img class="carousel-image" src="./new_images/hotel2.jpg">
        </div>
        <div class="carousel-item">
            <img class="carousel-image" src="./new_images/hotel3.jpg">
        </div>
        <div class="carousel-item">
            <img class="carousel-image" src="./new_images/hotel4.jpg">
        </div>

        <div class="welcomeline">
          <h1 class="welcometag">Unlock Your Next Adventure: <br> Book Your Perfect Stay with Us!</h1>
        </div>

      <!-- bookbox -->
      <div id="guestdetailpanel">
        <form action="" method="POST" class="guestdetailpanelform">
            <div class="head">
                <h3>RESERVATION</h3>
                <i class="fa-solid fa-circle-xmark" onclick="closebox()"></i>
            </div>
            <div class="middle">
                <div class="guestinfo">
                    <h4>Guest information</h4>
                    <input type="text" name="Name" placeholder="Enter Full name">
                    <input type="email" name="Email" placeholder="Enter Email">

                    <?php
                    $countries = array("Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegowina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei Darussalam", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo", "Congo, the Democratic Republic of the", "Cook Islands", "Costa Rica", "Cote d'Ivoire", "Croatia (Hrvatska)", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "East Timor", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "France Metropolitan", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard and Mc Donald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran (Islamic Republic of)", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, Democratic People's Republic of", "Korea, Republic of", "Kuwait", "Kyrgyzstan", "Lao, People's Democratic Republic", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libyan Arab Jamahiriya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia, The Former Yugoslav Republic of", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova, Republic of", "Monaco", "Mongolia", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Seychelles", "Sierra Leone", "Singapore", "Slovakia (Slovak Republic)", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "Spain", "Sri Lanka", "St. Helena", "St. Pierre and Miquelon", "Sudan", "Suriname", "Svalbard and Jan Mayen Islands", "Swaziland", "Sweden", "Switzerland", "Syrian Arab Republic", "Taiwan, Province of China", "Tajikistan", "Tanzania, United Republic of", "Thailand", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands (British)", "Virgin Islands (U.S.)", "Wallis and Futuna Islands", "Western Sahara", "Yemen", "Yugoslavia", "Zambia", "Zimbabwe");
                    ?>

                    <select name="Country" class="selectinput">
						<option value selected >Select your country</option>
                        <?php
							foreach($countries as $key => $value):
							echo '<option value="'.$value.'">'.$value.'</option>';
                            //close your tags!!
							endforeach;
						?>
                    </select>
                    <input type="text" name="Phone" placeholder="Enter Phoneno">
                </div>

                <div class="line"></div>

                <div class="reservationinfo">
                    <h4>Reservation information</h4>
                    <select name="RoomType" class="selectinput">
						<option value selected >Type Of Room</option>
                        <option value="Superior Room">SUPERIOR ROOM</option>
                        <option value="Deluxe Room">DELUXE ROOM</option>
						<option value="Guest House">GUEST HOUSE</option>
						<option value="Single Room">SINGLE ROOM</option>
                    </select>
                    <select name="Bed" class="selectinput">
						<option value selected >Bedding Type</option>
                        <option value="Single">Single</option>
                        <option value="Double">Double</option>
						<option value="Triple">Triple</option>
                        <option value="Quad">Quad</option>
						<option value="None">None</option>
                    </select>
                    <select name="NoofRoom" class="selectinput">
						<option value selected >No of Room</option>
                        <option value="1">1</option>
                        <!-- <option value="1">2</option>
                        <option value="1">3</option> -->
                    </select>
                    <select name="Meal" class="selectinput">
						<option value selected >Meal</option>
                        <option value="Room only">Room only</option>
                        <option value="Breakfast">Breakfast</option>
						<option value="Half Board">Half Board</option>
						<option value="Full Board">Full Board</option>
					</select>
                    <div class="datesection">
                        <span>
                            <label for="cin"> Check-In</label>
                            <input name="cin" type ="date">
                        </span>
                        <span>
                            <label for="cin"> Check-Out</label>
                            <input name="cout" type ="date">
                        </span>
                    </div>
                </div>
            </div>
            <div class="footer">
                <button class="btn btn-success" name="guestdetailsubmit">Submit</button>
            </div>
        </form>

        <!-- ==== room book php ====-->
        <?php       
            if (isset($_POST['guestdetailsubmit'])) {
                $Name = $_POST['Name'];
                $Email = $_POST['Email'];
                $Country = $_POST['Country'];
                $Phone = $_POST['Phone'];
                $RoomType = $_POST['RoomType'];
                $Bed = $_POST['Bed'];
                $NoofRoom = $_POST['NoofRoom'];
                $Meal = $_POST['Meal'];
                $cin = $_POST['cin'];
                $cout = $_POST['cout'];

                if($Name == "" || $Email == "" || $Country == ""){
                    echo "<script>swal({
                        title: 'Fill the proper details',
                        icon: 'error',
                    });
                    </script>";
                }
                else{
                    $sta = "NotConfirm";
                    $sql = "INSERT INTO roombook(Name,Email,Country,Phone,RoomType,Bed,NoofRoom,Meal,cin,cout,stat,nodays) VALUES ('$Name','$Email','$Country','$Phone','$RoomType','$Bed','$NoofRoom','$Meal','$cin','$cout','$sta',datediff('$cout','$cin'))";
                    $result = mysqli_query($conn, $sql);

                    
                        if ($result) {
                            echo "<script>swal({
                                title: 'Reservation successful',
                                icon: 'success',
                            });
                        </script>";
                        } else {
                            echo "<script>swal({
                                    title: 'Something went wrong',
                                    icon: 'error',
                                });
                        </script>";
                        }
                }
            }
            ?>
      </div>

    </div>
  </section>
    
  <section id="secondsection"> 
    <img src="./image/homeanimatebg.svg">
    <div class="ourroom">
      <h1 class="head"> Our rooms </h1>
      <div class="roomselect">
      <?php
        $server = "localhost";
        $username = "root";
        $password = "";
        $database = "luxestayhotel";
        
        $conn = mysqli_connect($server,$username,$password,$database);

        $query = "SELECT * FROM room";
        $result = mysqli_query($conn, $query);

        // Check if there are any rooms available
        if(mysqli_num_rows($result) > 0) {
            // Loop through each room and display its details
            $counter = 0;
            while($row = mysqli_fetch_assoc($result)) {

              if ($counter >= 4) {
                break; // Exit the loop if 4 rooms have been displayed
            }

                echo '<div class="roombox">';
                // echo '<div class="hotelphoto"><img class ="img" src="uploaded_img/' . $row['room_img'] . '" alt="Room Image"></div>';
                echo '<div class="hotelphoto " style="background-image: url(uploaded_img/' . $row['room_img'] . '">';
                // echo '<img class="img" src="uploaded_img/' . $row['room_img'] . '" alt="Room Image">';
                echo '</div>';

                echo '<div class="roomdata">';
                echo '<h2>' . $row['type'] . '</h2>'; // Assuming 'room_type' is a column in your database table
                echo '<div class="services">';
                // Assuming you have columns in your database indicating whether each service is available for the room
                // if($row['wifi'] == 1) {
                //     echo '<i class="fa-solid fa-wifi"></i>';
                // }
                // if($row['burger'] == 1) {
                //     echo '<i class="fa-solid fa-burger"></i>';
                // }
                // if($row['spa'] == 1) {
                //     echo '<i class="fa-solid fa-spa"></i>';
                // }
                // if($row['dumbbell'] == 1) {
                //     echo '<i class="fa-solid fa-dumbbell"></i>';
                // }
                // if($row['swimming_pool'] == 1) {
                //     echo '<i class="fa-solid fa-person-swimming"></i>';
                // }
                // echo '<div class="services">';
                if ($row['wifi'] == 1) {
                    echo '<i class="fa-solid fa-wifi"></i>';
                }
                if ($row['food'] == 1) {
                    echo '<i class="fa-solid fa-burger"></i>';
                }
                if ($row['spa'] == 1) {
                    echo '<i class="fa-solid fa-spa"></i>';
                }
                if ($row['gym'] == 1) {
                    echo '<i class="fa-solid fa-dumbbell"></i>';
                }
                if ($row['pool'] == 1) {
                    echo '<i class="fa-solid fa-person-swimming"></i>';
                }
                echo '<h3>' . $row['bedding'] . '</h3>';
                echo '</div>';
                echo '<button class="btn btn-primary bookbtn" onclick="openbookbox()">Book</button>';
                echo '</div>';
                echo '</div>';

                $counter++;
            }
        } else {
            echo "No rooms available.";
        }

        // Close the database connection
        mysqli_close($conn);
      ?>
        <!-- <div class="roombox">
          <div class="hotelphoto h1"></div>
          <div class="roomdata">
            <h2>Superior Room</h2>
            <div class="services">
              <i class="fa-solid fa-wifi"></i>
              <i class="fa-solid fa-burger"></i>
              <i class="fa-solid fa-spa"></i>
              <i class="fa-solid fa-dumbbell"></i>
              <i class="fa-solid fa-person-swimming"></i>
            </div>
            <button class="btn btn-primary bookbtn" onclick="openbookbox()">Book</button>
          </div>
        </div>
        <div class="roombox">
          <div class="hotelphoto h2"></div>
          <div class="roomdata">
            <h2>Delux Room</h2>
            <div class="services">
              <i class="fa-solid fa-wifi"></i>
              <i class="fa-solid fa-burger"></i>
              <i class="fa-solid fa-spa"></i>
              <i class="fa-solid fa-dumbbell"></i>
            </div>
            <button class="btn btn-primary bookbtn" onclick="openbookbox()">Book</button>
          </div>
        </div>
        <div class="roombox">
          <div class="hotelphoto h3"></div>
          <div class="roomdata">
            <h2>Guest Room</h2>
            <div class="services">
              <i class="fa-solid fa-wifi"></i>
              <i class="fa-solid fa-burger"></i>
              <i class="fa-solid fa-spa"></i>
            </div>
            <button class="btn btn-primary bookbtn" onclick="openbookbox()">Book</button>
          </div>
        </div>
        <div class="roombox">
          <div class="hotelphoto h4"></div>
          <div class="roomdata">
            <h2>Single Room</h2>
            <div class="services">
              <i class="fa-solid fa-wifi"></i>
              <i class="fa-solid fa-burger"></i>
            </div>
            <button class="btn btn-primary bookbtn" onclick="openbookbox()">Book</button>
          </div>
        </div> -->
      </div>
      <center>
      <form action="allRooms.php" method="post">
      <button  class="btn btn-primary viewAll_btn" onclick="">View all</button>
    </form>
      </center>

    </div>
  </section>

  
  
  <section id="thirdsection">
    <h1 class="head"> Facilities </h1>
    <div class="facility">
      <div class="box">
        <h2>Swiming pool</h2>
      </div>
      <div class="box">
        <h2>Spa</h2>
      </div>
      <div class="box">
        <h2>24*7 Restaurants</h2>
      </div>
      <div class="box">
        <h2>24*7 Gym</h2>
      </div>
      <!-- <div class="box">
        <h2>Heli service</h2>
      </div> -->
    </div>
  </section>
  
      
  
  <section style="background-image: url(./new_images/hotel5.jpg); background-size: cover;">
    <div style="display: flex; align-items: center; justify-content: center;">
      <div id="Log_in" style="width: 60%; padding: 20px; margin-bottom: 20px">
        <h2 style="color: white;">Contact us</h2>
        <!-- // ==userlogin== -->
        <?php 
        $server = "localhost";
        $username = "root";
        $password = "";
        $database = "luxestayhotel";
        
        $conn = mysqli_connect($server,$username,$password,$database);
        if (isset($_POST['contact_us'])) {
            $Name = $_POST['Name'];
            $Email = $_POST['Email'];
            $Subject = $_POST['Subject'];

            $sql = "INSERT INTO contact_us (name,email,subject) VALUES ('$Name', '$Email', '$Subject')";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                echo "<script>swal({
                  title: 'Successfully sent',
                  icon: 'success',
              });
              </script>";
            } else {
                echo "<script>swal({
                    title: 'Something went wrong',
                    icon: 'error',
                });
                </script>";
            }
        }
        ?>
        <div style="width: 100%;">
          <form class="user_login authsection active" id="userlogin" action="" method="POST">
              <div class="form-floating">
                  <input type="text" class="form-control" name="Name" placeholder=" ">
                  <label for="Username">Name</label>
              </div>
              <div class="form-floating">
                  <input typuser_logine="email" class="form-control" name="Email" placeholder=" ">
                  <label for="Email">Email</label>
              </div>
              <!-- <div class="form-floating">
                  <input type="password" class="form-control" name="Password" placeholder=" ">
                  <label for="Password">Password</label>
              </div> -->
              <div class="form-floating">
                  <input style="height:200px; margin-top: 15px;" type="text" class="form-control" name="Subject" placeholder=" ">
                  <!-- <textarea style="padding-top: 10px;" class="form-control" name="Subject" rows="10" placeholder=" "></textarea> -->

                  <label for="Subject">Subject</label>
              </div>
              <center>
              <button style="padding: 10px 50px;" type="submit" name="contact_us" class="btn btn-primary">Submit</button>

              </center>
          </form>
        </div>
        
      </div>
    </div>
  </section>



  <section id="contactus">
    <!-- <div class="social">
      <i class="fa-brands fa-instagram"></i>
      <i class="fa-brands fa-facebook"></i>
      <i class="fa-solid fa-envelope"></i>
    </div> -->

    <div style="display: flex; align-items: center; justify-content: center; width: 100%; color: white;">
      &copy; <span style="margin-left: 5px;"></span> <span style="color: white;" id="copyright-year"></span><span style="margin-right: 5px;"></span> LuxeStay. All rights reserved.
    </div>
  </section>

</body>

<script>

    var bookbox = document.getElementById("guestdetailpanel");

    openbookbox = () =>{
      bookbox.style.display = "flex";
    }
    closebox = () =>{
      bookbox.style.display = "none";
    }

    document.getElementById("copyright-year").textContent = new Date().getFullYear();
</script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script>
</html>