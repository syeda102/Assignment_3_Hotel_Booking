<?php
session_start();
include '../config.php';


if(isset($_POST['add_room'])){

    $typeOfRoom = $_POST['troom'];
    $typeOfBed = $_POST['bed'];
    $wifi = $_POST['wifi'];
    $food = $_POST['food'];
    $spa = $_POST['spa'];
    $gym = $_POST['gym'];
    $pool = $_POST['pool'];
    $image = $_FILES['image']['name'];
    $image_size = $_FILES['image']['size'];
    $image_tmp_name = $_FILES['image']['tmp_name'];
    // $image_folder = 'Hotel-Management-System/uploaded_img/'.$image;
    $image_folder = __DIR__ . '/../uploaded_img/' . $image;


    // echo($image);
 
    // $select_product_name = mysqli_query($conn, "SELECT name FROM `products` WHERE name = '$name'") or die('query failed');
 
    // if(mysqli_num_rows($select_product_name) > 0){
    //    $message[] = 'product name already added';
    // }else{
       $add_room_query = mysqli_query($conn, "INSERT INTO `room`( type, bedding, room_img, wifi, food, spa, gym, pool) VALUES('$typeOfRoom', '$typeOfBed', '$image', '$wifi', '$food', '$spa', '$gym', '$pool')") or die('query failed');
 
       if($add_room_query){
        //   if($image_size > 2000000){
        //      $message[] = 'image size is too large';
        //   }else{
            //  move_uploaded_file($image_tmp_name, $image_folder);
            //  $message[] = 'room added successfully!';

            if (move_uploaded_file($image_tmp_name, $image_folder)) {
                $message[] = 'room added successfully!';
                // echo("successful");
                echo "<script>swal({
                    title: 'Room added Successfully',
                    icon: 'success',
                });
                </script>";
            } else {
                $message[] = 'Failed to move uploaded file. Check directory permissions and path.';
                // echo("Failed");
                echo "<script>swal({
                    title: 'Something went wrong',
                    icon: 'error',
                });
                </script>";
            }
            
        //   }
       }else{
          $message[] = 'room could not be added!';
       }
    // }
 }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LuxeStay - Admin</title>
    <!-- fontowesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- boot -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/room.css">
</head>

<body>
    <!-- <div class="addroomsection"> -->
    <div style="display: flex; align-items: center; justify-content: center;">
        <div class="addRoomCard">
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="twoFeilds">
                    <div class="feilds">
                        <label for="troom">Type of Room :</label>
                        <select name="troom" class="form-control">
                            <option value selected></option>
                            <option value="Superior Room">SUPERIOR ROOM</option>
                            <option value="Deluxe Room">DELUXE ROOM</option>
                            <option value="Guest House">GUEST HOUSE</option>
                            <option value="Single Room">SINGLE ROOM</option>
                        </select>
                    </div>

                    <div class="feilds">
                        <label for="bed">Type of Bed :</label>
                        <select name="bed" class="form-control">
                            <option value selected></option>
                            <option value="Single">Single</option>
                            <option value="Double">Double</option>
                            <option value="Triple">Triple</option>
                            <option value="Quad">Quad</option>
                            <option value="Triple">None</option>
                        </select>
                    </div>
                </div>

                <div class="twoFeilds">
                    <div class="feilds">
                        <label for="wifi">Wifi :</label>
                        <select name="wifi" class="form-control">
                            <!-- <option value selected>Is wifi available</option> -->
                            <option value selected></option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>

                    <div class="feilds">
                        <label for="food">Food :</label>
                        <select name="food" class="form-control">
                            <!-- <option value selected>Is food available</option> -->
                            <option value selected></option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>
                </div>

                <div class="twoFeilds">
                    <div class="feilds">
                        <label for="spa">Spa :</label>
                        <select name="spa" class="form-control">
                            <!-- <option value selected>Is spa available</option> -->
                            <option value selected></option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>

                    <div class="feilds">
                        <label for="gym">Gym :</label>
                        <select name="gym" class="form-control">
                            <!-- <option value selected>Is gym available</option> -->
                            <option value selected></option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>
                </div>


                <div class="twoFeilds">
                    <div class="feilds">
                        <label for="pool">Swimming Pool :</label>
                        <select name="pool" class="form-control">
                            <!-- <option value selected>Is Swimming Pool available</option> -->
                            <option value selected></option>
                            <option value="1">Yes</option>
                            <option value="0">No</option>
                        </select>
                    </div>

                    <div class="feilds">
                        <label for="bed">Room Image :</label> 
                        <input type="file" name="image" accept="image/jpg, image/jpeg, image/png" class="box" required>
                    </div>
                </div>


                <center>
                    <input type="submit" value="Add Room" name="add_room" class="btn btn-success">

                </center>
                <!-- <button id="addRoomImageButton">Add Room Image</button>
                <input type="file" id="roomImageInput" style="display: none;" accept="image/*">

                <button id="addRoomButton" type="submit" class="btn btn-success" name="addroom">Add Room</button> --> 
                



            </form>

            <?php
            // if (isset($_POST['addroom'])) {
            //     $typeofroom = $_POST['troom'];
            //     $typeofbed = $_POST['bed'];

            //     $sql = "INSERT INTO room(type,bedding) VALUES ('$typeofroom', '$typeofbed')";
            //     $result = mysqli_query($conn, $sql);

            //     if ($result) {
            //         header("Location: room.php");
            //     }
            // }
            ?>

    <!-- <label for="bed">Room Image:</label>
                <button id="addRoomImageButton">Add Room Image</button>
                <input type="file" id="roomImageInput" style="position: absolute; top: -9999px; left: -9999px;" accept="image/*">

                <button type="submit" class="btn btn-success" name="addroom" id="addRoomButton">Add Room</button> -->
        </div>
    </div>

    <div class="room">
        <?php
        $sql = "select * from room";
        $re = mysqli_query($conn, $sql)
        ?>
        <?php
        while ($row = mysqli_fetch_array($re)) {
            $id = $row['type'];
            if ($id == "Superior Room") {
                echo "<div class='roombox roomboxsuperior'>
						<div class='text-center no-boder'>
                            <i class='fa-solid fa-bed fa-4x mb-2'></i>
							<h3>" . $row['type'] . "</h3>
                            <div class='mb-1'>" . $row['bedding'] . "</div>
                            <a href='roomdelete.php?id=". $row['id'] ."'><button class='btn btn-danger'>Delete</button></a>
						</div>
                    </div>";
            } else if ($id == "Deluxe Room") {
                echo "<div class='roombox roomboxdelux'>
                        <div class='text-center no-boder'>
                        <i class='fa-solid fa-bed fa-4x mb-2'></i>
                        <h3>" . $row['type'] . "</h3>
                        <div class='mb-1'>" . $row['bedding'] . "</div>
                        <a href='roomdelete.php?id=". $row['id'] ."'><button class='btn btn-danger'>Delete</button></a>
                    </div>
                    </div>";
            } else if ($id == "Guest House") {
                echo "<div class='roombox roomboguest'>
                <div class='text-center no-boder'>
                <i class='fa-solid fa-bed fa-4x mb-2'></i>
							<h3>" . $row['type'] . "</h3>
                            <div class='mb-1'>" . $row['bedding'] . "</div>
                            <a href='roomdelete.php?id=". $row['id'] ."'><button class='btn btn-danger'>Delete</button></a>
					</div>
            </div>";
            } else if ($id == "Single Room") {
                echo "<div class='roombox roomboxsingle'>
                        <div class='text-center no-boder'>
                        <i class='fa-solid fa-bed fa-4x mb-2'></i>
                        <h3>" . $row['type'] . "</h3>
                        <div class='mb-1'>" . $row['bedding'] . "</div>
                        <a href='roomdelete.php?id=". $row['id'] ."'><button class='btn btn-danger'>Delete</button></a>
                    </div>
                    </div>";
            }
        }
        ?>
    </div>

</body>

<script src="./javascript/addRoom.js"></script>
</html>